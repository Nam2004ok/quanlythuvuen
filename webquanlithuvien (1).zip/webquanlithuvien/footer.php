<style>
   a:hover {
      color: #3670EB !important;
      text-decoration: none !important;
   }
</style>
<section class="footer">
   <div class="box-container">
      <div class="box">
      <a href="home.php" class="logo"><img width="120px" height="100px" src="./images/logotv.png"></a>
      </div>
      <div class="box">
         <h3>Danh mục</h3>
         <a href="home.php">Trang chủ</a>
         <a href="list_new_books.php">Sách mới</a>
         <a href="search_page.php">Tìm kiếm</a>
         <a href="orders.php">Sách đã mượn</a>
      </div>

      <div class="box">
         <h3>Liên lạc</h3>
         <p> <i style="color: #3670EB !important;" class="fas fa-phone"></i> +84 983751738 </p>
         <p> <i style="color: #3670EB !important;" class="fas fa-phone"></i> +84 573192751 </p>
         <p> <i style="color: #3670EB !important;" class="fas fa-envelope"></i> hutechlibrary@gmail.com </p>
      </div>

      <div class="box">
         <h3>Theo dõi</h3>
         <a target="_blank" href=""> <i style="color: #3670EB !important;" class="fab fa-facebook-f"></i> facebook </a>
         <a target="_blank" href=""> <i style="color: #3670EB !important;" class="fab fa-instagram"></i> instagram </a>
      </div>

   </div>

</section>