<?php

    $conn = mysqli_connect('localhost','root','','webthuvien') or die('connection failed');
    $conn1 = mysqli_connect('localhost','root','','webthuvien') or die('connection failed');

?>